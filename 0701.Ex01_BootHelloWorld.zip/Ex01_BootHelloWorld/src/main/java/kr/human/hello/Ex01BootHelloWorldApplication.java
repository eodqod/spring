package kr.human.hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex01BootHelloWorldApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex01BootHelloWorldApplication.class, args);
	}

}
